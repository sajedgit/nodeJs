exports.myDateTime = function () {
    return Date();
};

exports.name = "sajed";

exports.sum = function (a,b) {
    return a+b;
};




/* function calculate(x)
{
	return x*10;
}


module.exports = calculate; */