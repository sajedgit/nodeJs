var age=30;
exports.myAge = function () {
	console.log(" i am called");
    return age;
};



 